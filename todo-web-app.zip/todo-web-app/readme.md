# Todo-Web-App

A simple Todo List Web App created using HTML, CSS, Bootstrap, and JavaScript.